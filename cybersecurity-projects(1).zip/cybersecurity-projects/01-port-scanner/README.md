# Port Scanner (Python)

A simple TCP port scanner built with Python's built-in `socket` module.

## What it does
- Checks whether specific ports on a target IP are open or closed
- Includes a fast multi-threaded scanning mode
- Identifies common services (HTTP, SSH, FTP, etc.) running on open ports

## Concepts covered
- Sockets and TCP/IP connections
- Threading for performance
- Basic networking (ports, protocols)

## Setup
No external libraries needed — uses Python's standard library only.

## Run
```
python port_scanner.py
```
You'll be prompted for:
- Target IP (use `127.0.0.1` to scan your own machine)
- Start port
- End port

## ⚠️ Legal Note
Only scan systems you own or have explicit written permission to test.
Scanning networks without permission is illegal in most countries.
