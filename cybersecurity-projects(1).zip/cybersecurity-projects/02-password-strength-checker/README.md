# Password Strength Checker

Rates password strength using rule-based checks and entropy calculation.

## What it does
- Checks length, uppercase/lowercase, digits, special characters
- Flags common/weak passwords (e.g. "password123")
- Calculates entropy (bits of randomness) to estimate brute-force resistance
- Gives an overall rating: WEAK / MODERATE / STRONG / VERY STRONG

## Concepts covered
- Regex pattern matching
- Entropy / information theory basics
- Rule-based scoring systems

## Setup
No external libraries needed — uses Python's standard library only.

## Run
```
python password_checker.py
```
Enter any password when prompted to see its strength report.
