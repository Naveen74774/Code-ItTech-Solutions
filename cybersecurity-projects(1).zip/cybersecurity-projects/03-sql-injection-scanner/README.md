# SQL Injection Vulnerability Scanner

Tests a web app's URL parameters for basic SQL injection vulnerabilities.

## What it does
- Sends common SQLi payloads (e.g. `' OR '1'='1`) as parameter values
- Checks the HTTP response for database error signatures
- Reports which parameters may be vulnerable
- Suggests using parameterized queries as a fix

## Concepts covered
- Web application security
- HTTP requests (GET params)
- Common SQLi attack patterns and defenses

## Setup
```
pip install requests
```

## Run
```
python sqli_scanner.py
```
You'll be prompted for:
- Target URL (e.g. `http://localhost:5000/search`)
- Parameter names to test (comma-separated, e.g. `id,search`)

## ⚠️ Legal Note
Only test websites/applications you own or have explicit written
permission to test. This is a basic educational scanner, not a
replacement for professional penetration testing tools.
